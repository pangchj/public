gunzip -S z ./*.svgz
./aa_change2.sh script*.svg
./aa_change2.sh special*.svg
./aa_change2.sh info\-insert.svg
./aa_change2.sh math-display.svg
gzip -S z ./*.svg
