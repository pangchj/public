gunzip -S z ./*.svgz
./aa_change2.sh *.svg
gzip -S z ./*.svg
